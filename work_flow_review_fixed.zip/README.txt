WORK FLOW LOGIN / SIGNUP SETUP

1. Open supabase-config.js.
2. Replace:
   PASTE_YOUR_SUPABASE_PROJECT_URL_HERE
   PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE
3. Upload index.html, supabase-config.js and logo.png to GitHub.
4. Vercel will redeploy.
5. Login and Sign Up buttons will appear in the navigation.

IMPORTANT:
This is a static HTML site. Vercel Environment Variables are not automatically available inside
a plain index.html file. The browser needs the Supabase Project URL and public publishable/anon key.
Never put a Supabase secret/service-role key in supabase-config.js.
